
import os
import json
import joblib
import numpy as np

def model_fn(model_dir):
    model = joblib.load(
        os.path.join(model_dir, "model.joblib")
    )
    return model

def input_fn(request_body, request_content_type):
    if request_content_type == "application/json":
        data = json.loads(request_body)

        if "instances" in data:
            return np.array(data["instances"])

        return np.array(data)

    raise ValueError(
        f"Unsupported content type: {request_content_type}"
    )

def predict_fn(input_data, model):
    return model.predict(input_data)

def output_fn(prediction, accept):
    return json.dumps({
        "predictions": prediction.tolist()
    })
